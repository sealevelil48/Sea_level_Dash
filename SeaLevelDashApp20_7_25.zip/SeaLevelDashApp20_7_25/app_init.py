from .Sea_Level_Dash_22_6_25 import SeaLevelDashboard
from sqlalchemy import create_engine
import os

def create_app():
    # Load environment variables
    DB_URI = os.getenv('DB_URI', "postgresql://postgres:sealevel123@localhost:5432/Test2-SeaLevels")
    
    # Create database engine
    engine = create_engine(
        DB_URI, 
        pool_pre_ping=True, 
        pool_size=15, 
        max_overflow=30, 
        pool_recycle=3600
    )
    
    # Initialize dashboard
    dashboard = SeaLevelDashboard(engine)
    return dashboard.create_app()